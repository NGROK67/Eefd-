# Discord Token Gen

**A Discord Account Creator**
 

## Setup

1. **Clone the repository**:
   ```bash
   cd your-repo
   ```

4. **Run the tool**:
   ```bash
   python main.py
   ```


## Donation

If you'd like to support this project, donations are greatly appreciated! Every bit helps with further development and maintenance.

## **Litecoin Address**: `Lc8BMFu5fnCNVLuyFi5Va6WjL6MFEBX9oG`

Thank you for your support!


## Contact The Creator

**Dm me on discord `lunarmart`.**

## Want A Custom Tool

**DM ME ON DISCORD WITH ALL THE DETAILS AND YOUR BUDGET**
